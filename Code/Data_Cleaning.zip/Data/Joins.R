Expedenture <- read_excel("~/Drexel/Quarter 4/Capstone/Project Work/Data/Expedenture.xlsx")
Proposal_Awards <- read_excel("~/Drexel/Quarter 4/Capstone/Project Work/Data/Proposal Awards.xlsx")
Proposals <- read_excel("~/Drexel/Quarter 4/Capstone/Project Work/Data/Proposals.xlsx")

class(Proposals$`Proposal Number`)
class(Proposal_Awards$`Proposal Number`)

Proposal_Awards$`Proposal Number`= as.factor(Proposal_Awards$`Proposal Number`)
Proposals$`Proposal Number`= as.factor(Proposals$`Proposal Number`)

#PRP= left_join(Proposals, Proposal_Awards, by= c("Proposal Number"))
#PRP2= full_join(Proposals, Proposal_Awards, by= c("Proposal Number"))

PRP=inner_join(Proposals, Proposal_Awards, by= c("Proposal Number"))

saveRDS(PRP, file="PRP2")

PRP$Banner= as.factor(PRP$Banner)
Expedenture$`Fund Code Key`= as.factor(Expedenture$`Fund Code Key`)

data=left_join(PRP, Expedenture, by = c("Banner"= "Fund Code Key")) # left then left join
#test=left_join(Expedenture,PRP , by = c("Fund Code Key"= "Banner"))# left then left join
#test1= full_join(Expedenture,PRP , by = c("Fund Code Key"= "Banner")) #left then outer join

#test3= full_join(Expedenture,PRP2 , by = c("Fund Code Key"= "Banner"))#full outer join 2 times

saveRDS(PRP2, file="PRP")
saveRDS(data, file="Left_then_Left")
saveRDS(test, file="LthenL_reversed")
saveRDS(test3, file="Outer_then_Outer")


#names(test)
#names(Expedenture)
#plot(Expedenture$`Z Year To Date Activity`)
#?hist
#summary(Expedenture$`Z Year To Date Activity`)
#count(unique(funds))

funds=Expedenture$`Z Year To Date Activity`
#length(unique(funds))

#length(unique(Expedenture$`Fsyr Code Key`))

key_fund=Expedenture %>%
  group_by(`Fund Code Key`) %>%
  summarise(funds= sum(`Z Year To Date Activity`))
hist(key_fund$funds)

ggplot(key_fund, aes(x=funds)) + geom_histogram() + ggtitle("Histogram of Funds")

