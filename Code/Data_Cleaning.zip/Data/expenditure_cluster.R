




unique(expenditure_clean$`College, School et al`)
expenditure_clean$`College, School et al`<-trimws(expenditure_clean$`College, School et al`)
#filter by cluster 1 -"College..School..Etc..y" 

expenditure_C1 <-expenditure_clean %>% filter(`College, School et al`  %in% c("College of Engineering","College of Arts and Science" ))
expenditure_C2 <-expenditure_clean %>% filter(`College, School et al`  %in% c("School of Biomedical Engineering, Science and Health Systems","College of Nursing and Health Professions","College of Computing & Informatics" ))
expenditure_C3 <-expenditure_clean %>% filter(`College, School et al`  %in% c("School of Education","LeBow College of Business" ,
                                                       "Goodwin College of Professional Studies" ,"Academy of Natural Sciences" ,
                                                       "Westphal College of Media Arts and Design" ,"Other: Other"))
expenditure_C4 <-expenditure_clean %>% filter(`College, School et al`  %in% c("Close School of Entrepreneurship","College of Law \r\r\n\""))
expenditure_C5 <-expenditure_clean %>% filter(`College, School et al`  %in% c("College of Medicine \r\r\n\""))
expenditure_C6<-expenditure_clean %>% filter(`College, School et al`  %in% c("School of Public Health" ,"Other: Office of Research","Other:  Government Relations","Other: VP Univ & Community Partnership"))




write.csv(expenditure_C1,"cluster_lag/expenditure_C1.csv")
write.csv(expenditure_C2,"cluster_lag/expenditure_C2.csv")
write.csv(expenditure_C3,"cluster_lag/expenditure_C3.csv")
write.csv(expenditure_C4,"cluster_lag/expenditure_C4.csv")
write.csv(expenditure_C5,"cluster_lag/expenditure_C5.csv")
write.csv(expenditure_C6,"cluster_lag/expenditure_C6.csv")

str(expenditure_C1$`Z Year To Date Activity`)

expenditure_C1_new <-aggregate(expenditure_C1$`Z Year To Date Activity`, by=list(`Fsyr Code Key`=expenditure_C1$`Fsyr Code Key`), FUN=sum)
names(expenditure_C1_new)<-c("Year","Net_Amt")

expenditure_C2_new <-aggregate(expenditure_C2$`Z Year To Date Activity`, by=list(`Fsyr Code Key`=expenditure_C2$`Fsyr Code Key`), FUN=sum)
names(expenditure_C2_new)<-c("Year","Net_Amt")

expenditure_C3_new <-aggregate(expenditure_C3$`Z Year To Date Activity`, by=list(`Fsyr Code Key`=expenditure_C3$`Fsyr Code Key`), FUN=sum)
names(expenditure_C3_new)<-c("Year","Net_Amt")

expenditure_C4_new <-aggregate(expenditure_C4$`Z Year To Date Activity`, by=list(`Fsyr Code Key`=expenditure_C4$`Fsyr Code Key`), FUN=sum)
names(expenditure_C4_new)<-c("Year","Net_Amt")

expenditure_C5_new <-aggregate(expenditure_C5$`Z Year To Date Activity`, by=list(`Fsyr Code Key`=expenditure_C5$`Fsyr Code Key`), FUN=sum)
names(expenditure_C5_new)<-c("Year","Net_Amt")

expenditure_C6_new <-aggregate(expenditure_C6$`Z Year To Date Activity`, by=list(`Fsyr Code Key`=expenditure_C6$`Fsyr Code Key`), FUN=sum)
names(expenditure_C6_new)<-c("Year","Net_Amt")

write.csv(expenditure_C1_new,"cluster_lag/expenditure_C1_new.csv")
write.csv(expenditure_C2_new,"cluster_lag/expenditure_C2_new.csv")
write.csv(expenditure_C3_new,"cluster_lag/expenditure_C3_new.csv")
write.csv(expenditure_C4_new,"cluster_lag/expenditure_C4_new.csv")
write.csv(expenditure_C5_new,"cluster_lag/expenditure_C5_new.csv")
write.csv(expenditure_C6_new,"cluster_lag/expenditure_C6_new.csv")
