
library(dplyr)
str(expenditure)

expenditure$`Fsyr Code Key`<-as.factor(expenditure$`Fsyr Code Key`)
expenditure$`Fspd Code Key`<-as.factor(expenditure$`Fspd Code Key`)
expenditure$`Fund Code Key`<-as.factor(expenditure$`Fund Code Key`)
expenditure$`Orgn Code Key`<-as.factor(expenditure$`Orgn Code Key`)
expenditure$`Acct Code Key`<-as.factor(expenditure$`Acct Code Key`)
expenditure$`Orgn Code 2`<-as.factor(expenditure$`Orgn Code 2`)
expenditure$`Orgn Code 3`<-as.factor(expenditure$`Orgn Code 3`)
expenditure$`Ftyp Code 2`<-as.factor(expenditure$`Ftyp Code 2`)
expenditure$`Frbgrnt Code`<-as.factor(expenditure$`Frbgrnt Code`)
expenditure$`2 digit cfda`<-as.factor(expenditure$`2 digit cfda`)
expenditure$`Frbgrnt Orgn Code Resp Office`<-as.factor(expenditure$`Frbgrnt Orgn Code Resp Office`)
expenditure$`Grnt Code`<-as.factor(expenditure$`Grnt Code`)
 

str(expenditure)

a<-(colSums(is.na(expenditure))/nrow(expenditure))*100
a<-as.data.frame(a)
a
which( colnames(expenditure)=="Frbgrnt Grnt Code Related" )

expenditure$`Frbgrnt Grnt Code Related`
unique(expenditure$`Frbgrnt Grnt Code Related`)
str(expenditure$`Frbgrnt Grnt Code Related`)

which( colnames(expenditure)=="Spriden Last Name2" )

expenditure$`Spriden Last Name2`
unique(expenditure$`Spriden Last Name2`)
str(expenditure$`Spriden Last Name2`)


expenditure<-expenditure[,-c(46,42)]


str(expenditure)
which( colnames(expenditure)=="PT Agency" )
str(expenditure$`PT Agency`)
unique(expenditure$`PT Agency`)
#do not delete for now substitue NA with "NA"
#substitute by "NA"
install.packages("forcats")
library(forcats) 
expenditure$`PT Agency`<-fct_explicit_na(expenditure$`PT Agency`, na_level = "NA")

which( colnames(expenditure)=="Frragpt Federal Fund Percent" )
expenditure$`Frragpt Federal Fund Percent`
unique(expenditure$`Frragpt Federal Fund Percent`)
str(expenditure$`Frragpt Federal Fund Percent`)
#substitute by 0
expenditure <- expenditure %>%
  mutate(`Frragpt Federal Fund Percent` = replace(`Frragpt Federal Fund Percent`,is.na(`Frragpt Federal Fund Percent`),0))

which( colnames(expenditure)=="Frragpt Agcy Pidm" )
expenditure$`Frragpt Agcy Pidm`
unique(expenditure$`Frragpt Agcy Pidm`)
str(expenditure$`Frragpt Agcy Pidm`)
#substitute by 0
expenditure <- expenditure %>%
  mutate(`Frragpt Agcy Pidm` = replace(`Frragpt Agcy Pidm`,is.na(`Frragpt Agcy Pidm`),0))

which( colnames(expenditure)=="ID" )
expenditure$`ID`
unique(expenditure$`ID`)
str(expenditure$`ID`)
expenditure$`ID`<-as.factor(expenditure$`ID`)
expenditure$`ID`<-fct_explicit_na(expenditure$`ID`, na_level = "NA")


which( colnames(expenditure)=="Frvcfda Cfda Code" )
expenditure$`Frvcfda Cfda Code`
unique(expenditure$`Frvcfda Cfda Code`)
str(expenditure$`Frvcfda Cfda Code`)
expenditure <- expenditure %>%
  mutate(`Frvcfda Cfda Code` = replace(`Frvcfda Cfda Code`,is.na(`Frvcfda Cfda Code`),0))


which( colnames(expenditure)=="Frvcfda Title" )
expenditure$`Frvcfda Title`
unique(expenditure$`Frvcfda Title`)
str(expenditure$`Frvcfda Title`)
expenditure$`Frvcfda Title`<-fct_explicit_na(expenditure$`Frvcfda Title`, na_level = "NA")

#Replace Na with String

which( colnames(expenditure)=="2 digit cfda" )
expenditure$`2 digit cfda`
unique(expenditure$`2 digit cfda`)
str(expenditure$`2 digit cfda`)
expenditure<-expenditure[,-c(29)]

which( colnames(expenditure)=="Frbgrnt Basi Code Ic" )
expenditure$`Frbgrnt Basi Code Ic`
unique(expenditure$`Frbgrnt Basi Code Ic`)
str(expenditure$`Frbgrnt Basi Code Ic`)


which( colnames(expenditure)=="Frbgrnt Indr Code Rate" )
expenditure$`Frbgrnt Indr Code Rate`
unique(expenditure$`Frbgrnt Indr Code Rate`)
str(expenditure$`Frbgrnt Indr Code Rate`)

which( colnames(expenditure)=="Frbgrnt Sponsor Id" )
expenditure$`Frbgrnt Sponsor Id`
unique(expenditure$`Frbgrnt Sponsor Id`)
str(expenditure$`Frbgrnt Sponsor Id`)


# remove na in r - remove rows - na.omit function / option
expenditure_clean <- na.omit(expenditure) 
a<-(colSums(is.na(expenditure_clean))/nrow(expenditure_clean))*100
a<-as.data.frame(a)
a

write.csv(expenditure_clean,file="expenditure_clean.csv")
