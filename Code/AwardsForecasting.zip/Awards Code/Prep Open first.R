library(tseries)
library(forecast)
library(readxl)
library(ggplot2)
library(zoo)
library(dyn)

clustaw=read_excel("finclustaward.xlsx")

clustaw$Date= as.Date(clustaw$Date)

colnames(clustaw)=c("Year","Quarter","Awards","Cluster","Date")

df1=subset(clustaw, clustaw$Cluster==1 & clustaw$Year != 2019)
df2=subset(clustaw,clustaw$Cluster==2 & clustaw$Year != 2019)
df3=subset(clustaw,clustaw$Cluster==3 & clustaw$Year != 2019)
df5=subset(clustaw,clustaw$Cluster==5 & clustaw$Year != 2019)
df6=subset(clustaw,clustaw$Cluster==6 & clustaw$Year != 2019)




