ggplot(df6, aes(Date, Awards)) + geom_line() + scale_x_date('quarter')  + ylab("Funds by Month") +
  xlab("")
count_ts1 = ts(df6[, c('Awards')]) #change this for awards and award$
df6$clean_cnt = tsclean(count_ts1)
ggplot() + 
  geom_line(data = df6, aes(x = Date, y = clean_cnt)) + scale_x_date('quarter')+ylab('Cleaned Funds Count')
df6$cnt_ma = ma(df6$clean_cnt, order=2) # using the clean count with no outliers
df6$cnt_ma4 = ma(df6$clean_cnt, order=4)

ggplot() + 
  geom_line(data = df6, aes(x = Date, y = clean_cnt, colour = "Counts")) +
  geom_line(data = df6, aes(x = Date, y = cnt_ma,   colour = "Bi-Yearly Moving Average"))  +
  geom_line(data = df6, aes(x = Date, y = cnt_ma4, colour = "Yearly Moving Average"))  +
  ylab('Bicycle Count') 

count_ma1 = ts(na.omit(df6$cnt_ma), frequency=2)
decomp1 = stl(count_ma1, s.window="periodic")
deseasonal_cnt1 <- seasadj(decomp1)
plot(decomp1)

adf.test(count_ma1, alternative = "stationary")
Acf(count_ma1, main='')
Pacf(count_ma1, main='')

count_d11 = diff(deseasonal_cnt1, differences = 2)
plot(count_d11)
adf.test(count_d11, alternative = "stationary")
Acf(count_d11, main='ACF for Differenced Series')
Pacf(count_d11, main='PACF for Differenced Series') 

auto.arima(deseasonal_cnt1, seasonal=F)

fit11= arima(deseasonal_cnt1, order = c(15,1,19))
summary(fit11)
tsdisplay(residuals(fit11), lag.max=45, main='(2,1,0) with Drift Model Residuals') 

fcast11 <- forecast(fit11, h=24)
View(fcast11)
autoplot(fcast11, main="Cluster 6 Five Year Award $ Prediction", xlab="Quarter", ylab="Award $")
#training/test for arima
hold1 <- window(ts(deseasonal_cnt1), start=31)

fit_no_holdout1 = arima(ts(deseasonal_cnt1[-c(31:38)]), order=c(15,1,19))
fcast_no_holdout1 <- forecast(fit_no_holdout1,h=8)
plot(fcast_no_holdout1, main="Cluster 6 Two Year Award $ Prediction with Test Set", xlab="Quarter", ylab="Award $")
lines(ts(deseasonal_cnt1))
