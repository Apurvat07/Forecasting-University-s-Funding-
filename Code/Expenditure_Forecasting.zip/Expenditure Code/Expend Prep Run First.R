library(tseries)
library(forecast)
library(readxl)
library(ggplot2)
library(zoo)
library(dyn)

clustexp=read_excel("finexpend.xlsx")

clustexp$Date= as.Date(clustexp$Date)


df1=subset(clustexp, clustexp$Cluster==1 & clustexp$Year != 2019)
df2=subset(clustexp,clustexp$Cluster==2 & clustexp$Year != 2019)
df3=subset(clustexp,clustexp$Cluster==3 & clustexp$Year != 2019)
df5=subset(clustexp,clustexp$Cluster==5 & clustexp$Year != 2019)
df6=subset(clustexp,clustexp$Cluster==6 & clustexp$Year != 2019)