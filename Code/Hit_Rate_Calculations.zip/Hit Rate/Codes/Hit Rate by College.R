#Data Prep
Awards <- read_excel("Awards awards FY 2009 - 2019 deident.xlsx")
Propos <- read_excel("DR-Sponsored Research Proposals_Awards proposals FY 2009-2019 deident.xlsx")

Propos$`Proposal Number`=as.factor(Propos$`Proposal Number`) 
Awards$`Proposal Number`=as.factor(Awards$`Proposal Number`)

propos_new_1=subset(Propos,Propos$`Proposal Type`== "New")
propos_new_2=subset(Propos,Propos$`Proposal Type`== "Revision")
propos_new_3=subset(Propos,Propos$`Proposal Type`== "Resubmission")
propos_new=rbind(propos_new_1,propos_new_2,propos_new_3)
propos_new$`College, School, Etc.`=trimws(propos_new$`College, School, Etc.`)


PRP_inner_1 = inner_join(Propos,Awards,by='Proposal Number') #merge award and propsal dataset by Proposal Number
merge_5=subset(PRP_inner_1,PRP_inner_1$`Proposal Type`== "New" |
                 PRP_inner_1$`Proposal Type`== "Revision" | PRP_inner_1$`Proposal Type`== "Resubmission" ) #merged award and proposal dataset

merge_5=merge_5[,c("Fiscal Year.x","Quarter","Proposal Type","Proposal Number","College, School, Etc..y","Fiscal Year.y","Fiscal Quarter")] #only keep related coulunms for hit rate

colnames(merge_5)[1:2]<- c("ProposFY","ProposQ") #rename colunms
colnames(merge_5)[6:7]<- c("AwardFY","AwardQ")#rename colunms
merge_5$LagFY= merge_5$AwardFY-merge_5$ProposFY
merge_5= merge_5 %>% filter (merge_5$LagFY>=0)



############Hit Rate by College
merge_5_c<- merge_5[order(merge_5$AwardFY,merge_5$AwardQ,merge_5$LagFY),]
merge_5_c$`College, School, Etc..y`=trimws(merge_5_c$`College, School, Etc..y`) #remove empty strings
unique(merge_5_c$`College, School, Etc..y`)

merge_5_c$ClusterbyCollege<- ifelse(merge_5_c$`College, School, Etc..y`  %in%  c("College of Engineering","College of Arts and Science" ), 1,
                                    ifelse(merge_5_c$`College, School, Etc..y`  %in%  c("School of Biomedical Engineering, Science and Health Systems","College of Nursing and Health Professions",
                                                                                        "College of Computing & Informatics" ), 2, 
                                           ifelse(merge_5_c$`College, School, Etc..y`%in%  c("School of Education","LeBow College of Business" ,"Goodwin College" ,
                                                                                             "Academy of Natural Sciences" ,"Westphal College of Media Arts and Design", NA),3,
                                                  ifelse(merge_5_c$`College, School, Etc..y` %in%  c("Close School of Entrepreneurship","College of Law"),4,
                                                         ifelse(merge_5_c$`College, School, Etc..y` %in%  c("College of Medicine"),5,6)))))


clu_1<-merge_5_c %>% filter(merge_5_c$`College, School, Etc..y` %in% 
                              c("College of Engineering","College of Arts and Science" ))

clu_2 <-merge_5_c %>% filter(merge_5_c$`College, School, Etc..y`  %in% 
                               c("School of Biomedical Engineering, Science and Health Systems","College of Nursing and Health Professions",
                                 "College of Computing & Informatics" ))
clu_3 <-merge_5_c %>% filter(merge_5_c$`College, School, Etc..y`  %in% 
                               c("School of Education","LeBow College of Business" ,"Goodwin College" ,
                                 "Academy of Natural Sciences" ,"Westphal College of Media Arts and Design", NA))
clu_4 <-merge_5_c %>% filter(merge_5_c$`College, School, Etc..y`  %in% c("Close School of Entrepreneurship","College of Law"))
clu_5 <-merge_5_c %>% filter(merge_5_c$`College, School, Etc..y`  %in% c("College of Medicine"))
clu_6 <-merge_5_c %>% filter(merge_5_c$`College, School, Etc..y`  %in% c("School of Public Health" ,"z Other"))


##Clsuter 1
propos_new$`College, School, Etc.`=trimws(propos_new$`College, School, Etc.`) #remove empty strings
clu_1_pro=propos_new %>% filter(propos_new$`College, School, Etc.` %in% 
                                  c("College of Engineering","College of Arts and Science" )) %>% group_by(`Fiscal Year`) %>% count() # total proposal amount for cluster 1

clu_1_2 <- clu_1 %>% group_by(`AwardFY`,`ProposFY`,`LagFY`) %>% count()
colnames(clu_1_2)[4] <- "Award Count"

#award count
clu_1_HitRate=aggregate(clu_1_2$`Award Count`, by = list(Year = clu_1_2$ProposFY), FUN = sum)
colnames(clu_1_HitRate)[1] <- "Fiscal Year"
clu_1_HitRate_c=full_join(clu_1_HitRate,clu_1_pro, by = "Fiscal Year")

#Hit Rate
clu_1_HitRate_c$HitRate=(clu_1_HitRate_c$x/clu_1_HitRate_c$n)*100
colnames(clu_1_HitRate_c)[2:4]<- c("Award Count","Proposal Count","Clsuter 1 - Hit Rate (%)")




##Clsuter 2
clu_2_pro=propos_new %>% filter(propos_new$`College, School, Etc.` %in% 
                                  c("School of Biomedical Engineering, Science and Health Systems","College of Nursing and Health Professions",
                                    "College of Computing & Informatics" )) %>% group_by(`Fiscal Year`) %>% count() # total proposal amount for cluster 2

clu_2_2 <- clu_2 %>% group_by(`AwardFY`,`ProposFY`,`LagFY`) %>% count()
colnames(clu_2_2)[4] <- "Award Count"

#award count
clu_2_HitRate=aggregate(clu_2_2$`Award Count`, by = list(Year = clu_2_2$ProposFY), FUN = sum)
colnames(clu_2_HitRate)[1] <- "Fiscal Year"
clu_2_HitRate_c=full_join(clu_2_HitRate,clu_2_pro, by = "Fiscal Year")

#Hit Rate
clu_2_HitRate_c$HitRate=(clu_2_HitRate_c$x/clu_2_HitRate_c$n)*100
colnames(clu_2_HitRate_c)[2:4]<- c("Award Count","Proposal Count","Clsuter 2 - Hit Rate (%)")



##Clsuter 3
clu_3_pro=propos_new %>% 
  filter(propos_new$`College, School, Etc.` %in% 
           c("School of Education","LeBow College of Business" ,"Goodwin College of Professional Studies" ,
             "Academy of Natural Sciences\r\r\nAcademy of Natural Sciences" ,"Westphal College of Media Arts and Design", NA )) %>% group_by(`Fiscal Year`) %>% count() # total proposal amount for cluster 3

clu_3_2 <- clu_3 %>% group_by(`AwardFY`,`ProposFY`,`LagFY`) %>% count()
colnames(clu_3_2)[4] <- "Award Count"

#award count
clu_3_HitRate=aggregate(clu_3_2$`Award Count`, by = list(Year = clu_3_2$ProposFY), FUN = sum)
colnames(clu_3_HitRate)[1] <- "Fiscal Year"
clu_3_HitRate_c=full_join(clu_3_HitRate,clu_3_pro, by = "Fiscal Year")

#Hit Rate
clu_3_HitRate_c$HitRate=(clu_3_HitRate_c$x/clu_3_HitRate_c$n)*100
colnames(clu_3_HitRate_c)[2:4]<- c("Award Count","Proposal Count","Clsuter 3 - Hit Rate (%)")



##Clsuter 4 --- not a good cluster so we don't need to focus or mention it
clu_4_pro=propos_new %>% filter(propos_new$`College, School, Etc.` %in% 
                                  c("Close School of Entrepreneurship","College of Law" )) %>% group_by(`Fiscal Year`) %>% count() # total proposal amount for cluster 4

clu_4_2 <- clu_4 %>% group_by(`AwardFY`,`ProposFY`,`LagFY`) %>% count()
colnames(clu_4_2)[4] <- "Award Count"

#award count
clu_4_HitRate=aggregate(clu_4_2$`Award Count`, by = list(Year = clu_4_2$ProposFY), FUN = sum)
colnames(clu_4_HitRate)[1] <- "Fiscal Year"
clu_4_HitRate_c=full_join(clu_4_HitRate,clu_4_pro, by = "Fiscal Year")

#Hit Rate
clu_4_HitRate_c$HitRate=(clu_4_HitRate_c$x/clu_4_HitRate_c$n)*100
colnames(clu_4_HitRate_c)[2:4]<- c("Award Count","Proposal Count","Clsuter 4 - Hit Rate (%)")



##Clsuter 5
clu_5_pro=propos_new %>% filter(propos_new$`College, School, Etc.` %in% 
                                  c("College of Medicine" )) %>% group_by(`Fiscal Year`) %>% count() # total proposal amount for cluster 5

clu_5_2 <- clu_5 %>% group_by(`AwardFY`,`ProposFY`,`LagFY`) %>% count()
colnames(clu_5_2)[4] <- "Award Count"

#award count
clu_5_HitRate=aggregate(clu_5_2$`Award Count`, by = list(Year = clu_5_2$ProposFY), FUN = sum)
colnames(clu_5_HitRate)[1] <- "Fiscal Year"
clu_5_HitRate_c=full_join(clu_5_HitRate,clu_5_pro, by = "Fiscal Year")

#Hit Rate
clu_5_HitRate_c$HitRate=(clu_5_HitRate_c$x/clu_5_HitRate_c$n)*100
colnames(clu_5_HitRate_c)[2:4]<- c("Award Count","Proposal Count","Clsuter 5 - Hit Rate (%)")


##Clsuter 6 -- someething happened from 2014-2018 (colleges mergered to Z other)
clu_6_pro=propos_new %>% filter(propos_new$`College, School, Etc.` %in% 
                                  c("School of Public Health" ,"Z Other" )) %>% group_by(`Fiscal Year`) %>% count() # total proposal amount for cluster 6

clu_6_2 <- clu_6 %>% group_by(`AwardFY`,`ProposFY`,`LagFY`) %>% count()
colnames(clu_6_2)[4] <- "Award Count"

#award count
clu_6_HitRate=aggregate(clu_6_2$`Award Count`, by = list(Year = clu_6_2$ProposFY), FUN = sum)
colnames(clu_6_HitRate)[1] <- "Fiscal Year"
clu_6_HitRate_c=full_join(clu_6_HitRate,clu_6_pro, by = "Fiscal Year")

#Hit Rate
clu_6_HitRate_c$HitRate=(clu_6_HitRate_c$x/clu_6_HitRate_c$n)*100
colnames(clu_6_HitRate_c)[2:4]<- c("Award Count","Proposal Count","Clsuter 6 - Hit Rate (%)")

