library(readxl)
library(dplyr)
library(corrplot)
library(tidyverse)
library(xlsx)
Expen <- read_excel("DR-Sponsored Research Expenditure full detail FY 2009 - 2019 deidentified.xlsx")
Awards <- read_excel("Awards awards FY 2009 - 2019 deident.xlsx")
Propos <- read_excel("DR-Sponsored Research Proposals_Awards proposals FY 2009-2019 deident.xlsx")

Propos$`Proposal Number`=as.factor(Propos$`Proposal Number`)
Awards$`Proposal Number`=as.factor(Awards$`Proposal Number`)

PRP_inner_1= inner_join(Propos,Awards,by='Proposal Number')


####Annual Hit Rate
propos_new_1=subset(Propos,Propos$`Proposal Type`== "New")
propos_new_2=subset(Propos,Propos$`Proposal Type`== "Revision")
propos_new_3=subset(Propos,Propos$`Proposal Type`== "Resubmission")
propos_new=rbind(propos_new_1,propos_new_2,propos_new_3)
propos_new$`College, School, Etc.`=trimws(propos_new$`College, School, Etc.`)

a=data.frame(propos_new %>%  group_by(`Proposal Number`,`Fiscal Year`,`Quarter`,`Proposal Type`) %>% count()) 
colnames(a)[2] <-"ProposFY"

count_props=propos_new %>%  group_by(`Fiscal Year`,`Quarter`,`Proposal Type`) %>% count() #starts at 2010 Q3
count_props_1=propos_new %>%  group_by(`Fiscal Year`,`Quarter`) %>% count() #starts at 2010 Q3 quarterly
count_props_3=propos_new %>%  group_by(`Fiscal Year`) %>% count() #starts at 2010 Q3 yearly
colnames(count_props_3)[1]<- "FY"

b=data.frame(Awards %>%  group_by(`Proposal Number`,`Fiscal Year`,`Fiscal Quarter`) %>% count()) 
colnames(b)[2] <- "AwardsFY"
Awards %>%  group_by(`Fiscal Year`,`Fiscal Quarter`) %>% count()

b_1= b %>% filter(!is.na(b$Proposal.Number))
b_1=b_1  %>% filter(!b_1$`AwardsFY`== 2008)
b_1=b_1 %>% filter(!b_1$`AwardsFY`== 2009)

#dropping duplicated awards with same proposal number
library(magrittr)
b_2=b_1 %>% group_by(b_1$Proposal.Number) %>% filter(AwardsFY==min(AwardsFY))
b_2=data.frame(b_2[,-5])


#remove inconsistent proposals
toBeRemoved= c('13030278','13081014','15010114','15060838',
               '15070974','15121878', '16010005','16010027','16010062','16010153',
               '16010155','16020169',	'16030367','16030424','16101464',
               '18121270','18121306','19030224','16030313','16030321','16030324','16030325',
               '16040572','16030320')

b_3=b_2[!b_2$Proposal.Number %in% toBeRemoved, ]

a$Proposal.Number=as.factor(a$Proposal.Number)
b_3$Proposal.Number=as.factor(b_3$Proposal.Number)


merge_1=inner_join(a,b_3, by= "Proposal.Number")


#create a lag year column
merge_1$LagFY= merge_1$AwardsFY-merge_1$ProposFY
merge_1= merge_1 %>% filter (merge_1$LagFY>=0)

merge_1 <- merge_1[order( merge_1$AwardsFY, merge_1$Fiscal.Quarter, merge_1$LagFY),]
count_props_1 <- count_props_1[order(count_props_1$`Fiscal Year`,count_props_1$`Quarter`),]

merge_2 <- merge_1 %>% group_by(`AwardsFY`,`ProposFY`,`LagFY`) %>% count()
colnames(merge_2)[4] <- "Award Count"

#award count
HitRate=aggregate(merge_2$`Award Count`, by = list(Year = merge_2$ProposFY), FUN = sum)
colnames(HitRate)[1] <- "FY"
HitRate=full_join(HitRate,count_props_3, by = "FY")

#Hit Rate
HitRate$HitRate=(HitRate$x/HitRate$n)*100
colnames(HitRate)[2:4]<- c("Award Count","Proposal Count","Hit Rate (%)")



####Quarterly Hit Rate

merge_1$QX_no<-as.integer(stringr::str_extract(merge_1$Fiscal.Quarter, "\\d+")) # AWARD
merge_1$QY_no<-as.integer(stringr::str_extract(merge_1$Quarter, "\\d+")) #PROPOSAL

merge_1$sub_Q<-merge_1$QX_no-merge_1$QY_no
merge_1$LagQuarter<-(merge_1$LagFY)*4-merge_1$sub_Q

merge_3= merge_1 %>% filter (merge_1$LagQuarter>=0)

merge_3 <- merge_3[order( merge_3$AwardsFY, merge_3$Fiscal.Quarter, merge_3$LagQuarter),]
count_props_1 <- count_props_1[order(count_props_1$`Fiscal Year`,count_props_1$`Quarter`),]

merge_4 <- merge_3 %>% group_by(`AwardsFY`,`Quarter`,`ProposFY`,`Fiscal.Quarter`,`LagQuarter`) %>% count()
colnames(merge_4)[2] <-"AwardQuarter"
colnames(merge_4)[4]  <- "ProposQuarter"
colnames(merge_4)[6]  <- "Award Count"

#award count
HitRate_Q=aggregate(merge_4$`Award Count`, by = list(Year = merge_4$ProposFY,Quarter=merge_4$ProposQuarter), FUN = sum)
colnames(HitRate_Q)[1] <- "Fiscal Year"
HitRate_Q=merge(HitRate_Q,count_props_1)

#Hit Rate
HitRate_Q$HitRate=(HitRate_Q$x/HitRate_Q$n)*100
colnames(HitRate_Q)[3:5]<- c("Award Count","Proposal Count","Hit Rate (%)")
