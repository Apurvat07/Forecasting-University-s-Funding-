#Data Prep

library("readxl")
Awards <- read_excel("Cleaned Awards_111819.xlsx")
Propos <- read_excel("Cleaned Proposal_111819.xlsx")
merged<-read.csv("merged(propos&award)111819.csv")
Propos$`Proposal Number`=as.factor(Propos$`Proposal Number`) 
Awards$`Proposal Number`=as.factor(Awards$`Proposal Number`)

propos_new_1=subset(Propos,Propos$`Proposal Type`=="New")
propos_new_2=subset(Propos,Propos$`Proposal Type`== "Revision")
propos_new_3=subset(Propos,Propos$`Proposal Type`== "Resubmission")
propos_new=rbind(propos_new_1,propos_new_2,propos_new_3)

unique(propos_new$Sponsor Type)


library("dplyr")

PRP_inner_1 = inner_join(Propos,Awards,by='Proposal Number') #merge award and propsal dataset by Proposal Number
merge_5=subset(PRP_inner_1,PRP_inner_1$`Proposal Type`== "New" |
                 PRP_inner_1$`Proposal Type`== "Revision" | PRP_inner_1$`Proposal Type`== "Resubmission" ) #merged award and proposal dataset
names(
  merge_5
)
merge_5=merge_5[,c("Fiscal Year.x","Quarter","Proposal Type","Proposal Number","Sponsor Type.x","Fiscal Year.y","Fiscal Quarter")] #only keep related coulunms for hit rate

colnames(merge_5)[1:2]<- c("ProposFY","ProposQ") #rename colunms
colnames(merge_5)[6:7]<- c("AwardFY","AwardQ")#rename colunms
merge_5$LagFY= merge_5$AwardFY-merge_5$ProposFY
merge_5= merge_5 %>% filter (merge_5$LagFY>=0)



############Hit Rate by Spomsor
merge_5_c<- merge_5[order(merge_5$AwardFY,merge_5$AwardQ,merge_5$LagFY),]
merge_5_c<-unique(merge_5_c)

unique(merge_5_c$`Sponsor Type.x`)

sp_1<-merge_5_c %>% filter(merge_5_c$`Sponsor Type.x` %in% c("Federal"))
sp_2<-merge_5_c %>% filter(merge_5_c$`Sponsor Type.x` %in% c("Private Non-Profit" ))
sp_3<-merge_5_c %>% filter(merge_5_c$`Sponsor Type.x` %in% c("Foreign Private Profit"))
sp_4<-merge_5_c %>% filter(merge_5_c$`Sponsor Type.x` %in% c("Industry - Private Profit"))
sp_5<-merge_5_c %>% filter(merge_5_c$`Sponsor Type.x` %in% c("Local Government"))
sp_6<-merge_5_c %>% filter(merge_5_c$`Sponsor Type.x` %in% c("Institution of Higher Education"))
sp_7<-merge_5_c %>% filter(merge_5_c$`Sponsor Type.x` %in% c("Foreign Institution of Higher Education"))
sp_8<-merge_5_c %>% filter(merge_5_c$`Sponsor Type.x` %in% c("Private Foundation"))
sp_9<-merge_5_c %>% filter(merge_5_c$`Sponsor Type.x` %in% c( "State"))
sp_10<-merge_5_c %>% filter(merge_5_c$`Sponsor Type.x` %in% c("Foreign Private Non-Profit"))
sp_11<-merge_5_c %>% filter(merge_5_c$`Sponsor Type.x` %in% c("Foreign Federal Government" ))
sp_12<-merge_5_c %>% filter(merge_5_c$`Sponsor Type.x` %in% c("Foreign Foundation"))

##1-Fedral
sp_1_pro=propos_new %>% filter(propos_new$`Sponsor Type` %in% 
                                  c("Federal" )) %>% group_by(`Fiscal Year`) %>% count() # total proposal amount for cluster 1
sp_1_2 <- sp_1 %>% group_by(`ProposFY`,`AwardFY`,`LagFY`) %>% count()
colnames(sp_1_2)[4] <- "Award Count"
#award count
sp_1_HitRate=aggregate(sp_1_2$`Award Count`, by = list(Year = sp_1_2$ProposFY), FUN = sum)
colnames(sp_1_HitRate)[1] <- "Fiscal Year"
sp_1_HitRate_c=full_join(sp_1_HitRate,sp_1_pro, by = "Fiscal Year")
#Hit Rate
sp_1_HitRate_c$HitRate=(sp_1_HitRate_c$x/sp_1_HitRate_c$n)*100
colnames(sp_1_HitRate_c)[2:4]<- c("Award Count","Proposal Count"," Fedral_Hit Rate (%)")
rownames(sp_1_HitRate_c)<-sp_1_HitRate_c[,1]

##2-
sp_2_pro=propos_new %>% filter(propos_new$`Sponsor Type` %in% 
                                 c("Private Non-Profit" )) %>% group_by(`Fiscal Year`) %>% count() # total proposal amount for cluster 1
sp_2_2 <- sp_2 %>% group_by(`ProposFY`,`AwardFY`,`LagFY`) %>% count()
colnames(sp_2_2)[4] <- "Award Count"
#award count
sp_2_HitRate=aggregate(sp_2_2$`Award Count`, by = list(Year = sp_2_2$ProposFY), FUN = sum)
colnames(sp_2_HitRate)[1] <- "Fiscal Year"
sp_2_HitRate_c=full_join(sp_2_HitRate,sp_2_pro, by = "Fiscal Year")
#Hit Rate
sp_2_HitRate_c$HitRate=(sp_2_HitRate_c$x/sp_2_HitRate_c$n)*100
colnames(sp_2_HitRate_c)[2:4]<- c("Award Count","Proposal Count","Private Non-Profit_Hit Rate (%)")
rownames(sp_2_HitRate_c)<-sp_2_HitRate_c[,1]

##3-
sp_3_pro=propos_new %>% filter(propos_new$`Sponsor Type` %in% 
                                 c("Foreign Private Profit")) %>% group_by(`Fiscal Year`) %>% count() # total proposal amount for cluster 1
sp_3_2 <- sp_3 %>% group_by(`ProposFY`,`AwardFY`,`LagFY`) %>% count()
colnames(sp_3_2)[4] <- "Award Count"
#award count
sp_3_HitRate=aggregate(sp_3_2$`Award Count`, by = list(Year = sp_3_2$ProposFY), FUN = sum)
colnames(sp_3_HitRate)[1] <- "Fiscal Year"
sp_3_HitRate_c=full_join(sp_3_HitRate,sp_3_pro, by = "Fiscal Year")
#Hit Rate
sp_3_HitRate_c$HitRate=(sp_3_HitRate_c$x/sp_3_HitRate_c$n)*100
colnames(sp_3_HitRate_c)[2:4]<- c("Award Count","Proposal Count","Foreign Private Profit_Hit Rate (%)")
rownames(sp_3_HitRate_c)<-sp_3_HitRate_c[,1]


#4
sp_4_pro=propos_new %>% filter(propos_new$`Sponsor Type` %in% 
                                 c("Industry - Private Profit")) %>% group_by(`Fiscal Year`) %>% count() # total proposal amount for cluster 1
sp_4_2 <- sp_4 %>% group_by(`ProposFY`,`AwardFY`,`LagFY`) %>% count()
colnames(sp_4_2)[4] <- "Award Count"
#award count
sp_4_HitRate=aggregate(sp_4_2$`Award Count`, by = list(Year = sp_4_2$ProposFY), FUN = sum)
colnames(sp_4_HitRate)[1] <- "Fiscal Year"
sp_4_HitRate_c=full_join(sp_4_HitRate,sp_4_pro, by = "Fiscal Year")
#Hit Rate
sp_4_HitRate_c$HitRate=(sp_4_HitRate_c$x/sp_4_HitRate_c$n)*100
colnames(sp_4_HitRate_c)[2:4]<- c("Award Count","Proposal Count","Industry - Private Profit_Hit Rate (%)")
rownames(sp_4_HitRate_c)<-sp_4_HitRate_c[,1]

#5
sp_5_pro=propos_new %>% filter(propos_new$`Sponsor Type` %in% 
                                 c("Local Government")) %>% group_by(`Fiscal Year`) %>% count() # total proposal amount for cluster 1
sp_5_2 <- sp_5 %>% group_by(`ProposFY`,`AwardFY`,`LagFY`) %>% count()
colnames(sp_5_2)[4] <- "Award Count"
#award count
sp_5_HitRate=aggregate(sp_5_2$`Award Count`, by = list(Year = sp_5_2$ProposFY), FUN = sum)
colnames(sp_5_HitRate)[1] <- "Fiscal Year"
sp_5_HitRate_c=full_join(sp_5_HitRate,sp_5_pro, by = "Fiscal Year")
#Hit Rate
sp_5_HitRate_c$HitRate=(sp_5_HitRate_c$x/sp_5_HitRate_c$n)*100
colnames(sp_5_HitRate_c)[2:4]<- c("Award Count","Proposal Count","Local Government_Hit Rate (%)")
rownames(sp_5_HitRate_c)<-sp_5_HitRate_c[,1]

#6
sp_6_pro=propos_new %>% filter(propos_new$`Sponsor Type` %in% 
                                 c("Institution of Higher Education")) %>% group_by(`Fiscal Year`) %>% count() # total proposal amount for cluster 1
sp_6_2 <- sp_6 %>% group_by(`ProposFY`,`AwardFY`,`LagFY`) %>% count()
colnames(sp_6_2)[4] <- "Award Count"
#award count
sp_6_HitRate=aggregate(sp_6_2$`Award Count`, by = list(Year = sp_6_2$ProposFY), FUN = sum)
colnames(sp_6_HitRate)[1] <- "Fiscal Year"
sp_6_HitRate_c=full_join(sp_6_HitRate,sp_6_pro, by = "Fiscal Year")
#Hit Rate
sp_6_HitRate_c$HitRate=(sp_6_HitRate_c$x/sp_6_HitRate_c$n)*100
colnames(sp_6_HitRate_c)[2:4]<- c("Award Count","Proposal Count","Institution of Higher Education_Hit Rate (%)")
rownames(sp_6_HitRate_c)<-sp_6_HitRate_c[,1]

##7
sp_7_pro=propos_new %>% filter(propos_new$`Sponsor Type` %in% 
                                 c("Foreign Institution of Higher Education")) %>% group_by(`Fiscal Year`) %>% count() # total proposal amount for cluster 1
sp_7_2 <- sp_7 %>% group_by(`ProposFY`,`AwardFY`,`LagFY`) %>% count()
colnames(sp_7_2)[4] <- "Award Count"
#award count
sp_7_HitRate=aggregate(sp_7_2$`Award Count`, by = list(Year = sp_7_2$ProposFY), FUN = sum)
colnames(sp_7_HitRate)[1] <- "Fiscal Year"
sp_7_HitRate_c=full_join(sp_7_HitRate,sp_7_pro, by = "Fiscal Year")
#Hit Rate
sp_7_HitRate_c$HitRate=(sp_7_HitRate_c$x/sp_7_HitRate_c$n)*100
colnames(sp_7_HitRate_c)[2:4]<- c("Award Count","Proposal Count","Foreign Institution of Higher Education_Hit Rate (%)")
rownames(sp_7_HitRate_c)<-sp_7_HitRate_c[,1]

##8-
sp_8_pro=propos_new %>% filter(propos_new$`Sponsor Type` %in% 
                                 c("Private Foundation" )) %>% group_by(`Fiscal Year`) %>% count() # total proposal amount for cluster 1
sp_8_2 <- sp_8 %>% group_by(`ProposFY`,`AwardFY`,`LagFY`) %>% count()
colnames(sp_8_2)[4] <- "Award Count"
#award count
sp_8_HitRate=aggregate(sp_8_2$`Award Count`, by = list(Year = sp_8_2$ProposFY), FUN = sum)
colnames(sp_8_HitRate)[1] <- "Fiscal Year"
sp_8_HitRate_c=full_join(sp_8_HitRate,sp_8_pro, by = "Fiscal Year")
#Hit Rate
sp_8_HitRate_c$HitRate=(sp_8_HitRate_c$x/sp_8_HitRate_c$n)*100
colnames(sp_8_HitRate_c)[2:4]<- c("Award Count","Proposal Count","Private Foundation_Hit Rate (%)")
rownames(sp_8_HitRate_c)<-sp_8_HitRate_c[,1]

##9-
sp_9_pro=propos_new %>% filter(propos_new$`Sponsor Type` %in% 
                                 c("State")) %>% group_by(`Fiscal Year`) %>% count() # total proposal amount for cluster 1
sp_9_2 <- sp_9 %>% group_by(`ProposFY`,`AwardFY`,`LagFY`) %>% count()
colnames(sp_9_2)[4] <- "Award Count"
#award count
sp_9_HitRate=aggregate(sp_9_2$`Award Count`, by = list(Year = sp_9_2$ProposFY), FUN = sum)
colnames(sp_9_HitRate)[1] <- "Fiscal Year"
sp_9_HitRate_c=full_join(sp_9_HitRate,sp_9_pro, by = "Fiscal Year")
#Hit Rate
sp_9_HitRate_c$HitRate=(sp_9_HitRate_c$x/sp_9_HitRate_c$n)*100
colnames(sp_9_HitRate_c)[2:4]<- c("Award Count","Proposal Count","State_Hit Rate (%)")
rownames(sp_9_HitRate_c)<-sp_9_HitRate_c[,1]


#10
sp_10_pro=propos_new %>% filter(propos_new$`Sponsor Type` %in% 
                                 c("Foreign Private Non-Profit")) %>% group_by(`Fiscal Year`) %>% count() # total proposal amount for cluster 1
sp_10_2 <- sp_10 %>% group_by(`ProposFY`,`AwardFY`,`LagFY`) %>% count()
colnames(sp_10_2)[4] <- "Award Count"
#award count
sp_10_HitRate=aggregate(sp_10_2$`Award Count`, by = list(Year = sp_10_2$ProposFY), FUN = sum)
colnames(sp_10_HitRate)[1] <- "Fiscal Year"
sp_10_HitRate_c=full_join(sp_10_HitRate,sp_10_pro, by = "Fiscal Year")
#Hit Rate
sp_10_HitRate_c$HitRate=(sp_10_HitRate_c$x/sp_10_HitRate_c$n)*100
colnames(sp_10_HitRate_c)[2:4]<- c("Award Count","Proposal Count","Foreign Private Non-Profit_Hit Rate (%)")
rownames(sp_10_HitRate_c)<-sp_10_HitRate_c[,1]

#11
sp_11_pro=propos_new %>% filter(propos_new$`Sponsor Type` %in% 
                                 c("Foreign Federal Government")) %>% group_by(`Fiscal Year`) %>% count() # total proposal amount for cluster 1
sp_11_2 <- sp_11 %>% group_by(`ProposFY`,`AwardFY`,`LagFY`) %>% count()
colnames(sp_11_2)[4] <- "Award Count"
#award count
sp_11_HitRate=aggregate(sp_11_2$`Award Count`, by = list(Year = sp_11_2$ProposFY), FUN = sum)
colnames(sp_11_HitRate)[1] <- "Fiscal Year"
sp_11_HitRate_c=full_join(sp_11_HitRate,sp_11_pro, by = "Fiscal Year")
#Hit Rate
sp_11_HitRate_c$HitRate=(sp_11_HitRate_c$x/sp_11_HitRate_c$n)*100
colnames(sp_11_HitRate_c)[2:4]<- c("Award Count","Proposal Count","Foreign Federal Government_Hit Rate (%)")
rownames(sp_11_HitRate_c)<-sp_11_HitRate_c[,1]

#12
sp_12_pro=propos_new %>% filter(propos_new$`Sponsor Type` %in% 
                                 c("Foreign Foundation")) %>% group_by(`Fiscal Year`) %>% count() # total proposal amount for cluster 1
sp_12_2 <- sp_12 %>% group_by(`ProposFY`,`AwardFY`,`LagFY`) %>% count()
colnames(sp_12_2)[4] <- "Award Count"
#award count
sp_12_HitRate=aggregate(sp_12_2$`Award Count`, by = list(Year = sp_12_2$ProposFY), FUN = sum)
colnames(sp_12_HitRate)[1] <- "Fiscal Year"
sp_12_HitRate_c=full_join(sp_12_HitRate,sp_12_pro, by = "Fiscal Year")
#Hit Rate
sp_12_HitRate_c$HitRate=(sp_12_HitRate_c$x/sp_12_HitRate_c$n)*100
colnames(sp_12_HitRate_c)[2:4]<- c("Award Count","Proposal Count","Foreign Foundation_Hit Rate (%)")
rownames(sp_12_HitRate_c)<-sp_12_HitRate_c[,1]



#merge
m2<-NULL
m2<-merge(sp_1_HitRate_c,sp_2_HitRate_c,by = "Fiscal Year")
m2<-merge(m2,sp_3_HitRate_c,by = "Fiscal Year",all = TRUE)
m2<-merge(m2,sp_4_HitRate_c,by = "Fiscal Year",all = TRUE)
m2<-merge(m2,sp_5_HitRate_c,by = "Fiscal Year",all = TRUE)
m2<-merge(m2,sp_6_HitRate_c,by = "Fiscal Year",all = TRUE)
m2<-merge(m2,sp_7_HitRate_c,by = "Fiscal Year",all = TRUE)
m2<-merge(m2,sp_8_HitRate_c,by = "Fiscal Year",all = TRUE)
m2<-merge(m2,sp_9_HitRate_c,by = "Fiscal Year",all = TRUE)
m2<-merge(m2,sp_10_HitRate_c,by = "Fiscal Year",all = TRUE)
m2<-merge(m2,sp_11_HitRate_c,by = "Fiscal Year",all = TRUE)
m2<-merge(m2,sp_12_HitRate_c,by = "Fiscal Year",all = TRUE)

write.csv(m2,"SponsorType_Hitrate.csv")
